package com.prolifics.ppmweb

import grails.converters.JSON

import com.prolifics.ppmweb.commons.core.LkupType
import com.prolifics.ppmweb.constant.Constants

class AccountingController {

    def messageService
	def accountingService
	def lkupTypeService
	def securityService

	def beforeInterceptor=[action:this.&beforeInterceptorAction]
	
	private beforeInterceptorAction = {}
	def company(){
		def companies=Company.list();
		def currencySource	=	lkupTypeService.getLkupsByGroupId(Constants.LKP_GROUP_TYPE_CUR_TYPE, 'sortOrder')
		
		[
			cmpnies:companies,
			currencySource:currencySource
		]
		
	}
	
	def save(){
		def jsonData
		def loggedUser		=	securityService.getAuthenticatedUser()
		def companyResult	=	accountingService.save(params, loggedUser.id)
		
		if(grailsApplication.isDomainClass(companyResult.getClass())) {
			session['pageInfoMessage'] =  (params?.id) ? session['pageInfoMessage'] = messageService.getMessage(Constants.UPDATE_SUCCESS_MESSAGE,'Company','')
					: messageService.getMessage(Constants.SAVE_SUCCESS_MESSAGE,'Company','')
			jsonData = [
				status:'Success',
				nextUrl: createLink(controller: 'accounting', action: 'company')
			]
		}else {
			jsonData = [
				status : 'Failure',
				pageErrorMessage: Constants.FAILURE_MESSAGE,
				fieldErrorMessages: companyResult
			]
		}
		render(jsonData as JSON)
	}
	
	def getCompany(){
		def companyDetails = accountingService.getCompanyDetails(params.compId)
		
		render companyDetails as JSON
		
	}
	
	
	def contractTerms(){
		def contractMappingSource= lkupTypeService.getLkupsByGroupId(Constants.LKP_GROUP_TYPE_CONTRACT_MAPPING, 'sortOrder')
		def	contractTermsSource	=	lkupTypeService.getLkupsByGroupId(Constants.LKP_GROUP_TYPE_CONTRACT_TERMS, 'sortOrder')
		[
			contractTermsSource		:	contractTermsSource,
			contractMappingSource	:	contractMappingSource 
		]
		
	}
	
	def saveContractMappings(){
		def jsonData
		def loggedUser		=	securityService.getAuthenticatedUser()
		def contractResult	=	accountingService.saveContractMappings(params, loggedUser.id)
		if(grailsApplication.isDomainClass(contractResult.getClass())) {
			session['pageInfoMessage'] =  (params?.contractTermId) ? session['pageInfoMessage'] = messageService.getMessage(Constants.UPDATE_SUCCESS_MESSAGE,'Contract','')
					: messageService.getMessage(Constants.SAVE_SUCCESS_MESSAGE,'Contract','')
			jsonData = [
				status:'Success',
				nextUrl: createLink(controller: 'accounting', action: 'contractTerms')
			]
		}
		render jsonData as JSON
		
	}
	
	def getContractMapping(){
		def contractData=[:]
		def contractMappingSource= lkupTypeService.getLkupsByGroupId(Constants.LKP_GROUP_TYPE_CONTRACT_MAPPING, 'sortOrder')
		def result=accountingService.getContractValues(params?.contractTermId)
		contractData.put('contractMappingSource', contractMappingSource)
		contractData.put('result', result)
		render contractData as JSON
	}
	
	def expenseTypes(){
		def expenseTypesSource	=	lkupTypeService.getLkupsByGroupId(Constants.LKP_GROUP_TYPE_PRJ_EXPENSES, 'sortOrder')
		def expenseMappingSource= lkupTypeService.getLkupsByGroupId(Constants.LKP_GROUP_TYPE_EXPENSES_MAPPING, 'sortOrder')
		[
			expenseTypesSource		:	expenseTypesSource,
			expenseMappingSource	:	expenseMappingSource
		]
		
	}
	
	def saveExpenseMappings(){
		def jsonData
		def loggedUser		=	securityService.getAuthenticatedUser()
		def expenseResult	=	accountingService.saveExpenseMappings(params, loggedUser.id)
		if(grailsApplication.isDomainClass(expenseResult.getClass())) {
			session['pageInfoMessage'] =  (params?.expenseTypeId) ? session['pageInfoMessage'] = messageService.getMessage(Constants.UPDATE_SUCCESS_MESSAGE,'Expense','')
					: messageService.getMessage(Constants.SAVE_SUCCESS_MESSAGE,'Expense','')
			jsonData = [
				status:'Success',
				nextUrl: createLink(controller: 'accounting', action: 'expenseTypes')
			]
		}
		render jsonData as JSON
		
	}
	
	def getExpenseMapping(){
		def expenseData=[:]
		def expenseMappingSource= lkupTypeService.getLkupsByGroupId(Constants.LKP_GROUP_TYPE_EXPENSES_MAPPING, 'sortOrder')
	
		def result=accountingService.getExpenseValues(params.expenseTypeId)
		expenseData.put('expenseMappingSource', expenseMappingSource)
		expenseData.put('result', result)
		render expenseData as JSON
	}
	
}
