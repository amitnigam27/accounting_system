package com.prolifics.ppmweb

import org.jadira.usertype.dateandtime.joda.PersistentLocalDateTime
import org.joda.time.LocalDateTime

import com.prolifics.ppmweb.commons.core.LkupType

class ExpenseMapping {
	Integer 			id
	LkupType			expenseTypeId
	LkupType			expenseMappingId
	Integer				glAccount
	LocalDateTime		dateCreated
	Integer             createdBy
	LocalDateTime		lastUpdated
	Integer             updatedBy

    static constraints = {
		glAccount			nullable:true
		expenseTypeId 		nullable:false
		expenseMappingId	nullable:false
		createdBy			nullable:false
		updatedBy			nullable:true
    }
	
	static mapping={
		table 'expense_mappings'
		version false
		expenseTypeId				column	:'typ_expense_type_id'
		expenseMappingId			column	:'typ_expense_mapping_id'
		glAccount					column	:'gl_account'
		dateCreated					type	: PersistentLocalDateTime, column	: 'date_created'
		lastUpdated					type	: PersistentLocalDateTime, column	: 'last_updated'
		createdBy					column	: 'created_by'
		updatedBy					column	: 'last_updated_by'
	}
}
