package com.prolifics.ppmweb

import grails.converters.JSON
import grails.transaction.Transactional

import com.prolifics.ppmweb.commons.core.LkupType

@Transactional
class AccountingService {

  def messageService

    def save(params, loggedUserId) {
	
		def company
		def companyResult
		def errExists
		def errMsg = [:]

		if(params.editId!="null"){
			company = Company.findById(params.int('editId'))
			
			company.updatedBy = loggedUserId as int
			
		}
		else{
			company=new Company()
			company.createdBy=loggedUserId as int
		}
			if(params.companyName){
				company.companyName=params.companyName
			}
			
			if(params.companyId){
				company.companyId=params.companyId
			}
			
			if(params.currency){
				company.currencyId= LkupType.get(params?.int('currency'))
			}
			if(params.costCenter){
				company.costCenter=params.costCenter
			}
			if(params.glAccount){
				company.glAccount=params.int('glAccount')
			}
			
		
		if(!company.validate()) {
			errExists = true
			errMsg = messageService.getErrorMessage(company)
		}
		if(errExists) {
			return errMsg
		} else {
			companyResult = company.save(flush:true)
			return companyResult
		}
    }
	
	def getCompanyDetails(compId){
		return Company.findById(compId)
			
	}
	
	def saveContractMappings(params,loggedUserId){
		def contractMapping
		def contractResult
		def cntrctMapping
		def formData=JSON.parse(params.dataObj);
		def contract = ContractMapping.findByContractTermId(LkupType.findById(params?.'contractTermId' as int))
		
			formData.each { key,value->
				if(contract!=null){
					cntrctMapping = ContractMapping.findByContractTermIdAndContractMappingId(LkupType.findById(params?.'contractTermId' as int), LkupType.findById(key as int))
					cntrctMapping.updatedBy = loggedUserId as int
				}
				else{
					cntrctMapping=new ContractMapping()
					cntrctMapping.createdBy				=	loggedUserId as int
				}
				cntrctMapping.contractTermId		=	LkupType.findById(params.contractTermId as int)
				cntrctMapping.contractMappingId		=	LkupType.findById(key as int)
				cntrctMapping.glAccount				=	(value == '') ? null : value as int
				contractResult 						= 	cntrctMapping.save(flush:true)
			}
		return contractResult
		}
	
	 def getContractValues(contractTermId){
		 	def result=ContractMapping.createCriteria().list{
				 projections{
					 property('contractMappingId.id')
					 property('glAccount')
				 }
				 eq('contractTermId', LkupType.findById(contractTermId as int))
				 
			 }		
			 def contractMap=[:]
			 result.each{it-> 
				 contractMap[it[0]]=it[1]
			 }
			 return contractMap
	 }
	 
	 
	 def saveExpenseMappings(params,loggedUserId){
		 def expenseMapping
		 def expenseResult
		 def expnsetMapping
		 def formData=JSON.parse(params.dataObj);
		 
		 def expense = ExpenseMapping.findByExpenseTypeId(LkupType.findById(params?.'expenseTypeId' as int))
				 
		 formData.each { key,value->
			 if(expense!=null){
				 expnsetMapping						=	ExpenseMapping.findByExpenseTypeIdAndExpenseMappingId(LkupType.findById(params?.'expenseTypeId' as int), LkupType.findById(key as int))
				 expnsetMapping.updatedBy 			= 	loggedUserId as int
			 }else{
			 	expnsetMapping=new ExpenseMapping()
				expnsetMapping.createdBy			=	loggedUserId as int
			 }
			 
			 expnsetMapping.expenseTypeId			=	LkupType.findById(params.expenseTypeId as int)
			 expnsetMapping.expenseMappingId		=	LkupType.findById(key as int)
			 expnsetMapping.glAccount				=	(value == '') ? null : value as int
			 expenseResult 							= 	expnsetMapping.save(flush:true)
		 }
		 return expenseResult
	 }
	 
	 
	def getExpenseValues(expenseTypeId){
			def result=ExpenseMapping.createCriteria().list{
					projections{
						property('expenseMappingId.id')
						property('glAccount')
					}
					eq('expenseTypeId', LkupType.findById(expenseTypeId as int))
		
				}
				def expenseMap=[:]
				result.each{it->
					expenseMap[it[0]]=it[1]
				}
				return expenseMap
	}
	 

}


