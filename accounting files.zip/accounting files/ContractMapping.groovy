package com.prolifics.ppmweb

import org.jadira.usertype.dateandtime.joda.PersistentLocalDateTime
import org.joda.time.LocalDateTime

import com.prolifics.ppmweb.commons.core.LkupType

class ContractMapping {
	
	Integer 			id
	LkupType			contractTermId
	LkupType			contractMappingId
	Integer				glAccount 
	LocalDateTime		dateCreated
	Integer             createdBy
	LocalDateTime		lastUpdated
	Integer             updatedBy

    static constraints = {
		glAccount			nullable:true
		contractTermId 		nullable:false
		contractMappingId	nullable:false
		createdBy			nullable:false
		updatedBy			nullable:true
    }
	
	static mapping={
		table 'contract_mappings'
		version false
		contractTermId				column	:'typ_contract_term_id'
		contractMappingId			column	:'typ_contract_mapping_id'
		glAccount					column	:'gl_account'
		dateCreated					type	: PersistentLocalDateTime, column	: 'date_created'
		lastUpdated					type	: PersistentLocalDateTime, column	: 'last_updated'
		createdBy					column	: 'created_by'
		updatedBy					column	: 'last_updated_by'
	}
}
